'''
from djitellopy import tello
import cv2


me = tello.Tello()

me.connect()

print("Battery level:", me.get_battery())

me.streamon()

while True:
    img = me.get_frame_read().frame
    img = cv2.resize(img,(360, 240))
    cv2.imshow('Image Capture', img)
    cv2.waitKey(1)
'''
from djitellopy import tello
import cv2
import time

me = tello.Tello()
me.connect()

print("Battery level:", me.get_battery())

me.streamon()

# Create a unique filename based on the current timestamp
timestamp = time.strftime("%Y%m%d_%H%M%S")
#photo_path = f"photo_{timestamp}.jpg"
photo_folder = "/Users/raychen/PycharmProjects/ML_finalProject/Tello Photo"
photo_path = f"{photo_folder}/photo_{timestamp}.jpg"

while True:
    img = me.get_frame_read().frame
    img = cv2.resize(img, (480, 360))
    cv2.imshow('Image Capture', img)

    key = cv2.waitKey(1)
    if key == ord('c'):  # Press 'c' to capture a photo
        cv2.imwrite(photo_path, img)
        print(f"Photo captured and saved as: {photo_path}")
    elif key == ord('q'):  # Press 'q' to quit the program
        break

cv2.destroyAllWindows()
me.streamoff()