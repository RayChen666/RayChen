import csv
import cv2
from cvzone.FPS import FPS
# define the video capture project and some other parameters
from collections import deque
from HandModel import KeyPointClassifier
from HandModel import PointHistoryClassifier


videoCaptureProject = None
main_window_closed_checker = False
camera_closed = False
grayscale_background = False

from PoseDetectionModule import detectPose
from JointDetectionModule import detectJoint
from BlurBackgroundModule import blurBackground
from FaceDetectionModule import detectFace
from HandDetectionModule import detectHands


pose_rendering_enabled = False
joint_rendering_enabled = False
background_blur_enabled = False
face_detection_enabled = False
hand_detection_enabled = False

# Create an instance of the FPS reader
fpsReader = FPS()

keypoint_classifier = KeyPointClassifier()
point_history_classifier = PointHistoryClassifier()
# Initialize the point history deque
point_history = deque(maxlen=16)

# Load the labels for keypoint classifier and point history classifier
keypoint_classifier_labels = []
with open('/Users/raychen/PycharmProjects/ML_finalProject/HandModel/KeyPointClassifier/keypoint_classifier_label.csv',
          encoding='utf-8-sig') as f:
    keypoint_classifier_labels = csv.reader(f)
    keypoint_classifier_labels = [row[0] for row in keypoint_classifier_labels]

point_history_classifier_labels = []
with open('/Users/raychen/PycharmProjects/ML_finalProject/HandModel/PointHistoryClassifier/point_history_classifier_label.csv',
          encoding='utf-8-sig') as f:
    point_history_classifier_labels = csv.reader(f)
    point_history_classifier_labels = [row[0] for row in point_history_classifier_labels]


while True:
    if not camera_closed and videoCaptureProject is None:
        videoCaptureProject = cv2.VideoCapture(0)

    if not camera_closed:
        ret, frame = videoCaptureProject.read()

        if not ret:
            print('Failure to read video from the camera.')
            break

        # Flip the frame horizontally
        frame = cv2.flip(frame, 1)


        # Check detectPose
        if pose_rendering_enabled:
            print("Performing pose detection and rendering")
            frame = detectPose(frame)

        # Check detectJoint
        if joint_rendering_enabled:
            frame = detectJoint(frame)

        # Check background removal
        if background_blur_enabled:
            frame = blurBackground(frame)

        # Check detectFace
        if face_detection_enabled:
            frame = detectFace(frame)

        # Check detectHands
        if hand_detection_enabled:
            #frame = detectHands(frame)
            frame = detectHands(frame, keypoint_classifier, point_history_classifier, point_history,
                                keypoint_classifier_labels, point_history_classifier_labels)

        # Change the background color based on the grayscale_background flag
        if grayscale_background:
            # Convert the video frame to grayscale
            gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            # Convert the grayscale frame back to BGR format
            frame = cv2.cvtColor(gray_frame, cv2.COLOR_GRAY2BGR)

        # Update and display FPS
        fps, frame = fpsReader.update(frame)
        #cv2.putText(frame, f"FPS: {int(fps)}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

        # Display the resulting frame
        if not main_window_closed_checker:
            cv2.imshow('video', frame)

    key = cv2.waitKey(1) & 0xFF
    # Press 'q' to close and quit the program
    if key == ord('q'):
        break
    # Press 'c' to close the current video and camera without quitting the program
    elif key == ord('c'):
        if not camera_closed:
            videoCaptureProject.release()
            cv2.destroyWindow('video')
            main_window_closed_checker = True
            camera_closed = True

    # Press 'o' to open the window
    elif key == ord('o'):
        if main_window_closed_checker:
            videoCaptureProject = cv2.VideoCapture(0)
            cv2.namedWindow('video')
            main_window_closed_checker = False
            camera_closed = False

    # Press 'g' to start/stop grayscale
    elif key == ord('g'):
        grayscale_background = not grayscale_background

    # Press 'p' to start/stop pose rendering
    elif key == ord('p'):
        pose_rendering_enabled = not pose_rendering_enabled

    # Press 'j' to start/stop joint rendering
    elif key == ord('j'):
        joint_rendering_enabled = not joint_rendering_enabled

    # Press 'r' to start/stop background blur
    elif key == ord('b'):
        background_blur_enabled = not background_blur_enabled
    # Press 'f' to start/stop face detection
    elif key == ord('f'):
        face_detection_enabled = not face_detection_enabled

    # Press 'h' to start/stop hand detection
    elif key == ord('h'):
        hand_detection_enabled = not hand_detection_enabled


if videoCaptureProject is not None:
    videoCaptureProject.release()
cv2.destroyAllWindows()