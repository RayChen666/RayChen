import cv2
import mediapipe as mp
import numpy as np

mp_selfie_segmentation = mp.solutions.selfie_segmentation
selfie_segmentation = mp_selfie_segmentation.SelfieSegmentation(model_selection=1)

def blurBackground(frame):
    # Flip the frame horizontally for a mirror effect
    #frame = cv2.flip(frame, 1)
    background_image = cv2.GaussianBlur(frame, (55, 55), 0)
    # Convert the frame to RGB format
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # Perform selfie segmentation
    results = selfie_segmentation.process(rgb_frame)

    # Extract the segmentation mask
    mask = results.segmentation_mask

    # Resize the background image to match the frame size
    background_resized = cv2.resize(background_image, (frame.shape[1], frame.shape[0]))

    # Apply the segmentation mask to the frame
    condition = np.stack((mask,) * 3, axis=-1) > 0.8
    output_frame = np.where(condition, frame, background_resized)


    return output_frame








